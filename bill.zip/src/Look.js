import React from 'react';
import Button from "react-bootstrap/Button";
import { Link } from 'react-router-dom';

const Look = () => {
  return (
    <>
    <Link to='/add'>
    <Button className="btn btn-info center m-lg-5">Add New Bill</Button>
    </Link>
    <Link to='/previous'>
    <Button className="btn btn-info center">Previous Bill</Button>
    </Link>
    </>
  )
}

export default Look;