import React from 'react'
// import Users from './users';
import Route1 from './Route1';
// import Look from './Look';
// import AddBill from './example';
// import InputND from './InputND';
// import TableCom from './TableCom';

const App = () => {
  return (
    <>
    {/* <InputND /> */}
    {/* <TableCom /> */}
    {/* <AddBill /> */}
    {/* <Look /> */}
    <Route1/>
    {/* <Users/> */}
    </> 
  )
}

export default App;